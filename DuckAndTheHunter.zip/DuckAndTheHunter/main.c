#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <time.h>

#include "files/boom.h"
#include "files/menu.h"
#include "files/data.h"
#include "files/game.h"
#include "files/lake.h"


void jatek(int kacsaszam, int start,int repul,int jutalom, Adatok a,int loszer, char lo, Fegyver f);
void menurajz(int kacsaszam, Adatok a, Fegyver f);
void kacsarajz(int kacsaszam, Adatok a);

int main()
{
    srand(time(0));
    struct Adatok a = {10, 1};
    struct Fegyver f;


    menurajz(a.kacsaszam, a, f);

    return 0;
}

