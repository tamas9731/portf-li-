#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <time.h>

#include "lake.h"
#include "data.h"


void kacsarajz(int kacsaszam, Adatok a)
{
    printf("\n\nEnnyi kacsa van a tavon: %d\n\n", a.kacsaszam);

    int i;

    for (i = 0; i < a.kacsaszam; i++)
    {
        printf(" # ");
    }
    printf("\n");
    for (i = 0; i < 10; i++)
    {
        printf("___");
    }
    printf("\n\n");
}
