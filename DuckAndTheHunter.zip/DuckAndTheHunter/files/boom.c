#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <time.h>

#include "boom.h"
#include "data.h"

void boomrajz()
{
    printf("--------------------\n");
    printf("--------BOOM--------\n");
    printf("--------------------\n");
    delay(1000);
    system("cls");
}

void delay(unsigned int mseconds)
{
    clock_t goal = mseconds + clock();
    while (goal > clock());
}
