#ifndef MENU_H_INCLUDED
#define MENU_H_INCLUDED

#include "data.h"

void menurajz(int kacsaszam, Adatok a, Fegyver f);


#endif // MENU_H_INCLUDED
