#ifndef DATA_H_INCLUDED
#define DATA_H_INCLUDED


typedef struct Adatok
{
    int start;
    int repul;
    int jutalom;
    int kacsaszam;

}Adatok;

typedef struct Fegyver
{
    int loszer;
    char lo[10];

}Fegyver;

#endif // DATA_H_INCLUDED
