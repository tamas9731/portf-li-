#ifndef LAKE_H_INCLUDED
#define LAKE_H_INCLUDED

#include "data.h"

void kacsarajz(int kacsaszam, Adatok a);

#endif // LAKE_H_INCLUDED
