#ifndef BOOM_H_INCLUDED
#define BOOM_H_INCLUDED

void boomrajz();

void delay(unsigned int mseconds);


#endif // BOOM_H_INCLUDED
