#ifndef GAME_H_INCLUDED
#define GAME_H_INCLUDED

#include "data.h"

void jatek(int kacsaszam, int start,int repul,int jutalom, Adatok a,int loszer, char lo, Fegyver f);


#endif // GAME_H_INCLUDED
