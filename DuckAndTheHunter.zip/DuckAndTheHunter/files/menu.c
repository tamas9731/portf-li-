#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <time.h>

#include "data.h"
#include "menu.h"
#include "game.h"
#include "lake.h"

void menurajz(int kacsaszam, Adatok a, Fegyver f)
{
    int orokke = 1;
    while (orokke)
    {
        kacsarajz(a.kacsaszam,a);
        system("cls");
        printf("        ..---.. \n");
        printf("      .'  _    `. \n");
        printf("  __..'  (o)    : \n");
        printf(" `..__          ;\n");
        printf("      `.       / \n");
        printf("        ;      `..---...___ \n");
        printf("      .'                   `~-. .-') \n");
        printf("     .                         ' _.' \n");
        printf("    :                           : \n");
        printf("    :                           ' \n");
        printf("     +                         J \n");
        printf("      `._                   _.' \n");
        printf("         `~--....___...---~' \n");

        printf("\n             1. Vadaszat\n");
        printf("             2. Kilepes\n");
        printf("\n           Mit csinaljak? : ");

        char valtozo;

        scanf("%c", &valtozo);
        getchar();


        switch(valtozo)
        {
        case 49:
            system("cls");
            a.start = 1;
            a.kacsaszam = rand()%10;
            jatek(a.kacsaszam, a.start, a.repul, a.jutalom, a, f.loszer, f.lo, f);
            orokke = 0;
            break;

        case 50:
            orokke = 0;
            break;
        }


        }


}
