#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <time.h>

#include "game.h"
#include "data.h"

void jatek(int kacsaszam, int start,int repul,int jutalom, Adatok a,int loszer, char lo, Fegyver f)
{

    if (a.kacsaszam <= 0)
    {
        system("cls");
        printf("Ma nincsenek kacsak a tavon!\n\nGyere vissza holnap!\n\n");
        printf("______________________________\n\n");
        a.start = 0;
    }
    else
    {
        //printf("Ennyi kacsa van a tavon: %d\n\n", a.kacsaszam);
    }

    while(a.start)
    {
        int jobeiras = 1;
        int talalat = 0;

        while(jobeiras)
            {
            kacsarajz(a.kacsaszam, a);

            printf("\n\nLoszer : %d\n", f.loszer);

            char valasz[] = "loves";

            printf("\nLoveshez ird be loves! : ");
            scanf("%s", &f.lo);
            getchar();

            if (strcmp(valasz, f.lo) == 0)
            {
                f.loszer--;
                talalat = rand()%2;
                jobeiras = 0;
                system("cls");
            }
            else
            {
                system("cls");
            }
            }


        if (talalat == 1)
        {
            boomrajz();

            a.repul = rand()%2;

            int levon = rand()%3;
            if (levon <= 0)
            {
                levon++;
            }

            a.kacsaszam -=levon;
            a.jutalom += levon;
            printf("Eltalaltal %d kacsat", levon);

            if (a.kacsaszam <= 0)
            {
                a.start = 0;
            }

            if (a.repul == 0)
            {
                printf(", de a hangra a tobbi elijedt!");
                a.kacsaszam = 0;
                kacsarajz(a.kacsaszam, a);
            }
            else
            {
                printf(", es a tobbi sem repult el");
                if (a.kacsaszam > 0)
                {
                    printf("\n\nMaradek kacsa : %d\n", a.kacsaszam);
                }
                //kacsarajz(a.kacsaszam, a);
            }
        }

        else
        {
            a.kacsaszam = 0;
            boomrajz();
            kacsarajz(a.kacsaszam, a);
            printf("Nem talaltal el egyet sem,es a hangra mind elrepult!");
            if (a.kacsaszam > 0)
            {
                printf("\n\nMaradek kacsa : %d\n", a.kacsaszam);
            }
            a.start = 0;
        }

        if (f.loszer <= 0)
        {
            a.start = 0;
        }

        if (a.kacsaszam <= 0)
        {
            printf("\n\nNem maradt tobb kacsa.\n\n");
            a.start = 0;
        }

    }

    printf("Ennyi a kacsat vihetsz haza : %d\n\n", a.jutalom);
    system("pause");
    a.jutalom = 0;
    menurajz(a.kacsaszam, a);
}
